from django.apps import AppConfig


class CareConfig(AppConfig):
    name = 'care'
