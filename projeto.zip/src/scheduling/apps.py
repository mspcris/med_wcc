from django.apps import AppConfig


class SchedulingConfig(AppConfig):
    name = 'scheduling'
